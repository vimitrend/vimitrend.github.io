VIMI TREND — GITHUB PAGES UPLOAD (TWO ZIP PARTS)

IMPORTANT: Download BOTH ZIP files. Extract both into the SAME folder. If asked to replace/merge folders, choose merge. Then upload the CONTENTS of that combined folder to the ROOT of https://github.com/vimitrend/vimitrend.github.io and commit. Do NOT upload the ZIP files themselves.

The large products data has been divided into 4 JSON parts, each below 25 MB. Keep products.json and all four products-part-*.json files together in the repository root. index.html and p.html automatically load and combine all four parts. No product records or original product photos were removed.

Cloudflare Worker deployment still requires the GitHub Actions secrets described below. Never share your API token in chat.

VIMI TREND — COMPLETE GITHUB PAGES + CLOUDFLARE PACKAGE

Website: https://vimitrend.github.io/
Worker: https://vimi-trend-links.vimitrend.workers.dev

IMPORTANT: GitHub Pages does NOT publish a ZIP file as a website. Extract this ZIP first, then upload the CONTENTS (files and folders) to the ROOT of https://github.com/vimitrend/vimitrend.github.io. Do not upload the ZIP itself as the only file.

Included website files: index.html, p.html, products.json, logo.jpg, videos/ (if present), plus worker.js, wrangler.toml and .github/workflows/deploy-worker.yml. Keep the .github folder structure.

Cloudflare Worker auto-deployment requires a one-time GitHub Actions setup:
1) GitHub repository → Settings → Secrets and variables → Actions → New repository secret.
2) Add CLOUDFLARE_ACCOUNT_ID with value 4fa98b7d67b401f80f570bbd67d8edfd.
3) Add CLOUDFLARE_API_TOKEN with your own Cloudflare API Token. Create it in Cloudflare → My Profile → API Tokens. Do not share the token with anyone. It needs permission to deploy Workers Scripts and use the existing Workers KV namespace.
4) Commit/push the files to branch main. GitHub Actions will deploy worker.js.

KV binding is already set in wrangler.toml:
VIMI_TREND_ORDERS = d0ca3afdbff14345b49a36d9cb5d1f43
Do not change it. Keep Cloudflare on Free plan; quotas apply.

After upload, check GitHub Actions for a successful Worker deployment, then open https://vimi-trend-links.vimitrend.workers.dev/health.


GITHUB UPLOAD NOTE:
products.json is now a small manifest. Upload every products-part-*.json file beside it. The website loads and combines all parts automatically. Keep all part files in the repository root. Each JSON file is below 25 MB.
