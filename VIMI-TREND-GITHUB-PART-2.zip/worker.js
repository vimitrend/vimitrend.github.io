// VIMI TREND — Cloudflare Worker short order links
// Required KV binding: VIMI_TREND_ORDERS
// Site: https://vimitrend.github.io
const SITE_BASE = 'https://vimitrend.github.io';
const ALLOWED_ORIGIN = 'https://vimitrend.github.io';
const cors = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Methods': 'POST, OPTIONS, GET',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Max-Age': '86400',
  'Vary': 'Origin'
};
function json(data, status=200){
  return new Response(JSON.stringify(data), {status, headers:{...cors,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
}
function makeId(){
  const b = new Uint8Array(9); crypto.getRandomValues(b);
  return Array.from(b, x=>x.toString(16).padStart(2,'0')).join('');
}
function base64UrlUtf8(value){
  const bytes = new TextEncoder().encode(value);
  let binary='';
  for(let i=0;i<bytes.length;i+=0x8000) binary += String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
export default {
  async fetch(request, env){
    const url = new URL(request.url);
    if(request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
    if(url.pathname === '/health') return json({ok:true,service:'VIMI TREND short links'});
    if(url.pathname === '/api/shorten' && request.method === 'POST'){
      const origin = request.headers.get('Origin') || '';
      if(origin !== ALLOWED_ORIGIN) return json({error:'Origin not allowed'},403);
      if(!env.VIMI_TREND_ORDERS) return json({error:'KV binding VIMI_TREND_ORDERS is missing'},500);
      let body;
      try{ body = await request.json(); }catch(e){ return json({error:'Invalid JSON'},400); }
      if(!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 500) return json({error:'items must contain 1 to 500 order items'},400);
      const payload = JSON.stringify(body.items);
      if(payload.length > 900000) return json({error:'Order is too large for a short link'},413);
      const id = makeId();
      await env.VIMI_TREND_ORDERS.put(id,payload,{expirationTtl:31536000});
      const shortUrl = new URL('/o/'+id, request.url).toString();
      return json({ok:true,shortUrl,id,expiresInDays:365});
    }
    if(url.pathname.startsWith('/o/') && request.method === 'GET'){
      if(!env.VIMI_TREND_ORDERS) return new Response('Short-link storage is not configured.',{status:500});
      const id = url.pathname.slice(3).replace(/[^a-f0-9]/gi,'');
      if(!id || id.length !== 18) return new Response('Invalid order link.',{status:400});
      const payload = await env.VIMI_TREND_ORDERS.get(id);
      if(!payload) return new Response('This order link has expired or is unavailable.',{status:404,headers:{'Content-Type':'text/plain; charset=utf-8'}});
      const encoded = base64UrlUtf8(payload);
      return Response.redirect(SITE_BASE+'/p.html#order='+encoded,302);
    }
    return json({error:'Not found'},404);
  }
};
